public class DualNumber {
  public double u;
  public double uprime;

  public DualNumber(double number, double derivate) {
    this.u = number;
    this.uprime = derivate;
  }
}
