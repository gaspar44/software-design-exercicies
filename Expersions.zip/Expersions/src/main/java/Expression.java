public interface Expression {

  DualNumber evaluate(DualNumber dualNumber);
}
